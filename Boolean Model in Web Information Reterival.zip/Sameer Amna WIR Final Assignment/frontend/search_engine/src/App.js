import logo from './logo.svg';
import './App.css';
import SearchPage from './SearchPage';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div className="App">
    <SearchPage/>
    </div>
  );
}

export default App;
