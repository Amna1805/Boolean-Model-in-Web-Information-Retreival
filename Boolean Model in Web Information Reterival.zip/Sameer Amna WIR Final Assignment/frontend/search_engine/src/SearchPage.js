import React, { useState } from 'react';
import axios from 'axios';
import './App.css';
import img from './images/search.jpg'
import img1 from './images/s2.avif'
const SearchPage = () => {
  const [query, setQuery] = useState('');
  const [Andquery, setAndquery] = useState('');
  const [ORquery, setORquery] = useState('');
  const [NOTquery, setNOTquery] = useState('');
  const [results, setResults] = useState([]);
  const [error, setError] = useState('');
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);

  const handleSearch = () => {
    fetch(`http://localhost:5000/search?query=${query}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Error fetching search results.');
        }
        return response.json();
      })
      .then(data => {
        setResults(data);
        setError('');
      })
      .catch(error => {
        setError(error.message);
        setResults([]);
      });
  };
  const getSearchQuery = () => {
    return `${query} "AND" ${Andquery} "OR" ${ORquery} "NOT" ${NOTquery}"`;
  };
  const handleadvancedSearch = () => {
     console.log("eelll")
    fetch(`http://localhost:5000/search?query=${query}&andquery=${Andquery}&orquery=${ORquery}&notquery=${NOTquery}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Error fetching search results.');
        }
        return response.json();
      })
      .then(data => {
        setResults(data);
        setError('');
      })
      .catch(error => {
        setError(error.message);
        setResults([]);
      });
  };

  const handleAdvancedSearchClick = () => {
    setShowAdvancedSearch(true); // Show advanced search
  };
  const handlegeneralSearchClick = () => {
    setShowAdvancedSearch(false); // Show advanced search
  };

  const handleSearchClick = () => {
    setShowAdvancedSearch(false); // Hide advanced search
    handleSearch(); // Perform regular search
  };

  return (
    <>
   <div style={{ position: 'relative' }}>
  <img
    src={img}
    alt="Background Image"
    style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '400px',
      zIndex: -1, // Ensure it's behind other content
    }}
  />
  <h2 className="text-center p-2 ">Search Engine Assignment</h2>
  {/* <h5 className="text-center mt-2">Group Members:</h5> */}
  <h6 className="text-center ">Sameer Khan 04072013020</h6>
  <h6 className="text-center ">Amna Muzaffar 04072013003</h6>
</div>
    <div className="container">
      <div className="row justify-content-center mt-3">
        <div className="col-md-6 col-6">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="form-control"
            placeholder="Enter your search query"
          />
        </div>
        {!showAdvancedSearch && (
          <>
            <div className="col-md-1 col-1">
              <button onClick={handleSearchClick} className="btn btn-primary">Search</button>
            </div>
            <div className="col-md-2 col-2">
              <button onClick={handleAdvancedSearchClick} className="btn btn-secondary">Advanced Search</button>
            </div>
          </>
        )}
      </div>
      {showAdvancedSearch && (
        <div className="row justify-content-center mt-3">
          <div className="col-md-2">
            <input
              type="text"
              className="form-control mb-2"
              onChange={(e) => setAndquery(e.target.value)}
              placeholder="AND"
            />
          </div>
          <div className="col-md-2">
            <input
              type="text"
              className="form-control mb-2"
              placeholder="OR"
              onChange={(e) => setORquery(e.target.value)}
            />
          </div>
          <div className="col-md-2">
            <input
              type="text"
              className="form-control mb-2"
              placeholder="NOT"
              onChange={(e) => setNOTquery(e.target.value)}
            />
          </div>
          <div className="col-md-1">
            <button onClick={handleadvancedSearch} className="btn btn-primary">Search</button>
          </div>
          <div className="col-md-2">
            <button onClick={handlegeneralSearchClick} className="btn btn-secondary">Close</button>
          </div>
          <p className='p-2 text-center mt-5'><i><b>Search Query: {getSearchQuery()}</b></i></p>
        </div>
      )}
      {error && <p className="text-danger mt-5">{error}</p>}
      <div className="mt-5">
        <h3 className='p-2 mt-5'><i>Search Results:</i></h3>
        <ul className="list-group">
          {results.map((result, index) => (
            <li key={index} className="list-group-item">
              <a href={result.url} target="_blank" rel="noopener noreferrer">
                {result.title}
              </a>
              <p>{result.page_body}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
    </>
  );
};

export default SearchPage;
