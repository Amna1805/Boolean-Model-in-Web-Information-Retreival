from flask import Flask, request, jsonify
from bs4 import BeautifulSoup
import requests
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

class SearchEngine:
    def __init__(self, inverted_index_path, meta_file_path):
        self.inverted_index_path = inverted_index_path
        self.meta_file_path = meta_file_path
        self.inverted_index = self._load_inverted_index()
        self.meta_data = self._load_meta_data()

    def _load_inverted_index(self):
        inverted_index = {}
        with open(self.inverted_index_path, "r", encoding="utf-8") as index_file:
            next(index_file)  # Skip the first line
            for line in index_file:
                if not line.strip():
                    continue  # Skip empty lines
                parts = line.strip().split("|")
                word = parts[0]
                doc_ids = parts[2].split()
                inverted_index[word] = doc_ids
        return inverted_index

    def _load_meta_data(self):
        meta_data = {}

        with open("meta.txt", "r", encoding="utf-8") as meta_file:
            entries = meta_file.read().strip().split("\n\n")  # Split by empty lines to get each entry
            
            for entry in entries:
                lines = entry.strip().split("\n")  # Split each entry by lines
                page_info = {}
                page_body_lines = []  # Initialize a list to store page body lines

                for line in lines:
                    parts = line.split(": ", 1)
                    if len(parts) == 2:
                        key = parts[0]
                        value = parts[1]
                        if key == "Page Body":
                            page_body_lines.append(value.strip())  # Append the page body line
                        else:
                            page_info[key] = value.strip()  # Add other key-value pairs to page_info dictionary

                if "Web Page ID" in page_info:
                    page_id = page_info["Web Page ID"]
                    url = page_info.get("URI", "")
                    title = page_info.get("Title", "")
                    page_body = "\n".join(page_body_lines)  # Concatenate page body lines into a single string

                    meta_data[page_id] = {
                        "url": url,
                        "title": title,
                        "page_body": ' '.join(page_body.split()[:50])
                    }


        return meta_data


    def search(self, query):
        result_docs = set()
        for word in query.split():
            if word in self.inverted_index:
                result_docs.update(self.inverted_index[word])
        return list(result_docs)

    def advanced_search(self, query, and_query, or_query, not_query):
        # Find documents matching the main query
        main_results = set(self.search(query))
        print("main",main_results)

        # Find documents matching the AND query
        and_results = set()
        if and_query:
            and_terms = and_query.split()
            and_results = set.intersection(*[set(self.search(term)) for term in and_terms])
            print("And",and_results)

        # Find documents matching the OR query
        or_results = set()
        if or_query:
            or_terms = or_query.split()
            or_results = set.union(*[set(self.search(term)) for term in or_terms])
            print("OR",or_results)

        # Find documents matching the NOT query
        not_results = set()
        if not_query:
            print("not query",not_query)
            not_terms = not_query.split()
            not_results = set.union(*[set(self.search(term)) for term in not_terms])
            print("NOT",not_results)

        # Combine results
        final_results = main_results.intersection(and_results)
        print("final",final_results)
        final_results.update(or_results)
        print("final",final_results)
        final_results.difference_update(not_results)
        print("final",final_results)

        return final_results

    def get_meta_info(self, doc_ids):
        meta_info = []
        for doc_id in doc_ids:
            if doc_id in self.meta_data:
                meta_info.append(self.meta_data[doc_id])
        return meta_info


search_engine = SearchEngine("inverted_index.txt", "meta.txt")

@app.route("/search", methods=["GET"])
def search():
    query = request.args.get("query", "")
    and_query = request.args.get("andquery", "")
    or_query = request.args.get("orquery", "")
    not_query = request.args.get("notquery", "")

    if and_query or or_query or not_query:
        # Apply logic for AND, OR, and NOT queries
        result_docs = search_engine.advanced_search(query, and_query, or_query, not_query)
    else:
        # Perform regular search
        result_docs = search_engine.search(query)

    meta_info = search_engine.get_meta_info(result_docs)
    return jsonify(meta_info)
if __name__ == "__main__":
    app.run(debug=True)
